public class Num2 {
    public static void main(String[] args) {
        int i = 0;
        int j = 10;
        i++;
        j--;
        System.out.println(i);  // 1 출력
        System.out.println(j);  // 9 출력
    }
}
