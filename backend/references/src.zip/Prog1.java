public class Prog1 {
    public static void main(String[] args) {
        System.out.print(7); // print() 메소드는 줄바꿈을 하지 않음
        System.out.println(3);
        System.out.println(3.14);		// 실수 출력
		System.out.println("자바!!");	// 문자열 출력
		System.out.println("문자열끼리의 " + "연결도 가능합니다.");
		System.out.println("숫자" + 3 + "과 문자열의 연결도 가능합니다.");
    }
}
