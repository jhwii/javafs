package a0628;

public class Ex4_1 {
    //score 에 80을 대입후   if문으로 score가 60이상이면   "합격입니다."  를 출력하시오
    public static void main(String[] args) {
        int score = 80;

		if (score >= 60) {
			System.out.println("합격입니다.");
		}
    }

}
