package a0628;

public class Ex3_9 {
    public static void main(String[] args) {
        int a = 1_000_000;
        int b = 1_000_000; 
        long c = a * b;  
        System.out.println(c);
    }
}
