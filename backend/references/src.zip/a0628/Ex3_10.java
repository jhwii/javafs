package a0628;

public class Ex3_10 {
    public static void main(String[] args) {
        long c = 1000000L * 1000000;
        long a = 1_000_000 * 1_000_000;
		long b = 1_000_000 * 1_000_000L;

		System.out.println("a="+a);
		System.out.println("b="+b);
        System.out.println("c="+c);
    }
}
