package a0628;

public class Ex3_12 {
    public static void main(String[] args) {
        int x = 10;
		int y = 8;
        // 10을 8로나누면, 
        // 몫은 1이고, 나머지는 2 입니다.
        System.out.printf("%d을 %d로 나누면, %n", x , y);
        System.out.printf("몫은 %d이고, 나머지는 %d입니다. %n", x / y , x % y );
    }
}
