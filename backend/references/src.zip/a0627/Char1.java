package a0627;

public class Char1 {
    public static void main(String[] args) {
        char ch1 = '한';
		char ch2 = '\uD55C';  // /u는 unicode를 나타냄
		
		System.out.println(ch1);
		System.out.println(ch2);
    }
}
