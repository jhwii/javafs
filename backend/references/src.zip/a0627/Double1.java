package a0627;

public class Double1 {
    public static void main(String[] args) {
        
        double dnum = 3.14;
		float fnum = 3.14f;//float로 선언할 경우 뒤에 f를 꼭 붙여주자
		
		System.out.println(dnum);
		System.out.println(fnum);
    }
}
