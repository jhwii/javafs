public class String1 {
    public static void main(String[] args) {
        String a = "Happy Java";
        String b = "a";
        String c = "123";
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);

    }
}
