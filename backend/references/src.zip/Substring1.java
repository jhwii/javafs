public class Substring1 {
    public static void main(String[] args) {
        String a = "Hello Java";
        System.out.println(a.substring(0, 4));  // Hell 출력
    }
}
