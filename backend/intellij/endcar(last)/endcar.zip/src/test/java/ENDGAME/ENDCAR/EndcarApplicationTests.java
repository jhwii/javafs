package ENDGAME.ENDCAR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EndcarApplicationTests {

	@Test
	void contextLoads() {
	}

}
