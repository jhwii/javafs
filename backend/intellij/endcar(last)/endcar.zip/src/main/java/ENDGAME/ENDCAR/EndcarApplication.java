package ENDGAME.ENDCAR;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EndcarApplication {

	public static void main(String[] args) {
		SpringApplication.run(EndcarApplication.class, args);
	}

}
