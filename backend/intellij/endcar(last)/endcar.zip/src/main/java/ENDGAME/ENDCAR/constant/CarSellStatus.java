package ENDGAME.ENDCAR.constant;

public enum CarSellStatus {
    SELL, SOLD_OUT, CANCEL
}
