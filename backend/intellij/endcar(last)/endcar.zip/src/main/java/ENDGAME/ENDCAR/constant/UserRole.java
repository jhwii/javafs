package ENDGAME.ENDCAR.constant;

public enum UserRole {
    USER, ADMIN;
}
