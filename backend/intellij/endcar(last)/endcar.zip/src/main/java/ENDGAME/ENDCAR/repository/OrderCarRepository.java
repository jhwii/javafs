package ENDGAME.ENDCAR.repository;

import ENDGAME.ENDCAR.entity.OrderCar;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderCarRepository extends JpaRepository<OrderCar, Long> {
}
