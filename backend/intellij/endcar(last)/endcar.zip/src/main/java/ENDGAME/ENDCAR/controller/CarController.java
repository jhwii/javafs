package ENDGAME.ENDCAR.controller;

import ENDGAME.ENDCAR.dto.CarFormDto;
import ENDGAME.ENDCAR.service.AuthenticationFacade;
import ENDGAME.ENDCAR.service.CarService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/security-login")
public class CarController {
    private final CarService carService;
    private  final AuthenticationFacade authenticationFacade;

    @GetMapping("/carForm")
    public String carForm(Model model) {
        model.addAttribute("carFormDto", new CarFormDto());
        return "car/carForm";
    }

    @PostMapping(value = "car/carForm")
    public String carNew(@Valid CarFormDto carFormDto, BindingResult bindingResult,
                         Model model, @RequestParam("carImgFile") List<MultipartFile> carImgFileList) {
        if (bindingResult.hasErrors()) {
            return "dto/carForm";
        }
        if (carImgFileList.get(0).isEmpty() && carFormDto.getId() == null) {
            model.addAttribute("errorMessage", "첫번째 상품 이미지는 필수 입력 값 입니다.");
            return "dto/carForm";
        }
        try {
            carService.saveCar(carFormDto, carImgFileList);
        } catch (Exception e) {
            model.addAttribute("errorMessage", "상품 등록 중 에러가 발생하였습니다.");
            return "dto/carForm";
        }

        return "redirect:/security-login";
    }
}